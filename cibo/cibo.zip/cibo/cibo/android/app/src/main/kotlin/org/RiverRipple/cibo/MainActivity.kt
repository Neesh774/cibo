package org.RiverRipple.cibo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
